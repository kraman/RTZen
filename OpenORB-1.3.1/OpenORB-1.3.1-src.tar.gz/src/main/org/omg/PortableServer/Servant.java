package org.omg.PortableServer;

import org.omg.CORBA.ORB;
import org.omg.PortableServer.POA;

import org.openorb.util.ExceptionTool;

/**
 * Servant class
 */

abstract public class Servant
{
    final public org.omg.CORBA.Object _this_object()
    {
        return _get_delegate().this_object( this );
    }

    final public org.omg.CORBA.Object _this_object( ORB orb )
    {
        try
        {
            ( ( org.omg.CORBA_2_3.ORB ) orb ).set_delegate( this );
        }
        catch( final ClassCastException ex )
        {
            throw ExceptionTool.initCause( new org.omg.CORBA.BAD_PARAM( 
                    "POA Servant requires an instance of org.omg.CORBA_2_3.ORB (" + 
                    ex + ")" ), ex );
        }

        return _this_object();
    }

    final public ORB _orb()
    {
        return _get_delegate().orb( this );
    }

    // No more standard, wait...
    final public void _orb( ORB orb )
    {
        try
        {
            ( ( org.omg.CORBA_2_3.ORB ) orb ).set_delegate( this );
        }
        catch( final ClassCastException ex )
        {
            throw ExceptionTool.initCause( new org.omg.CORBA.BAD_PARAM( 
                    "POA Servant requires an instance of org.omg.CORBA_2_3.ORB (" + 
                    ex + ")" ), ex );
        }
    }

    final public POA _poa()
    {
        return _get_delegate().poa( this );
    }

    final public byte [] _object_id()
    {
        return _get_delegate().object_id( this );
    }


    public POA _default_POA()
    {
        return _get_delegate().default_POA( this );
    }

    public boolean _is_a( String repid )
    {
        return _get_delegate().is_a( this, repid );
    }

    public boolean _non_existent()
    {
        return _get_delegate().non_existent( this );
    }

    /**
    *@deprecated Depreacted by CORBA 2.4
    */
    public org.omg.CORBA.InterfaceDef _get_interface()
    {
        return org.omg.CORBA.InterfaceDefHelper.narrow( _get_delegate().get_interface_def( this ) );
    }

    private int _hasGetInterface = -1;

    public org.omg.CORBA.Object _get_interface_def()
    {
        // bit of mucking around here to ensure old overrides remain valid.
        if ( _hasGetInterface < 0 )
        {
            Class clz = getClass();
            _hasGetInterface = 0;

            while ( !clz.equals( Servant.class ) )
            {
                try
                {
                    clz.getDeclaredMethod( "_get_interface", null );
                    _hasGetInterface = 1;
                    break;
                }
                catch ( NoSuchMethodException ex )
                {}
                catch ( SecurityException ex )
                {}

                clz = clz.getSuperclass();
            }
        }

        if ( _hasGetInterface > 0 )
            return _get_interface();
        else
            return _get_delegate().get_interface_def( this );
    }

    // methods for which the skeleton or application programmer must
    // provide for an implementation

    abstract public String [] _all_interfaces( POA poa, byte [] objectId );

    // private implementation methods

    private transient org.omg.PortableServer.portable.Delegate _delegate = null;

    final public org.omg.PortableServer.portable.Delegate _get_delegate()
    {
        if ( _delegate == null )
        {
            throw new org.omg.CORBA.BAD_INV_ORDER( "The Servant has not been associated with an ORB instance" );
        }

        return _delegate;
    }

    final public void _set_delegate( org.omg.PortableServer.portable.Delegate __delegate )
    {
        _delegate = __delegate;
    }
}
