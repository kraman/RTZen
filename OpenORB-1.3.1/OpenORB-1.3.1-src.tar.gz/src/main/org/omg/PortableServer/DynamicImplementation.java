package org.omg.PortableServer;

/**
 * This interface must be implemented to provide a dynamic skeleton.
 */

abstract public class DynamicImplementation extends Servant
{
    abstract public void invoke( org.omg.CORBA.ServerRequest request );
}
