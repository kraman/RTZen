/***** Copyright (c) 1999 Object Management Group. Unlimited rights to
     duplicate and use this code are hereby granted provided that this 
     copyright notice is included.
*****/

package org.omg.CORBA.ORBPackage;

public final class InvalidName extends org.omg.CORBA.UserException
{

    public InvalidName()
    {
        super( "IDL:omg.org/CORBA/ORB/InvalidName:1.0" );
    }

    public InvalidName( String reason_str )
    { // full constructor
        super( "IDL:omg.org/CORBA/ORB/InvalidName:1.0 " + reason_str );
    }
}
