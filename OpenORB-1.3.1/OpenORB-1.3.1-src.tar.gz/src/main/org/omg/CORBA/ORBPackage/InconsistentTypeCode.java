/***** Copyright (c) 1999 Object Management Group. Unlimited rights to
     duplicate and use this code are hereby granted provided that this 
     copyright notice is included.
*****/

package org.omg.CORBA.ORBPackage;

public final class InconsistentTypeCode extends org.omg.CORBA.UserException
{

    public InconsistentTypeCode()
    {
        super( "IDL:omg.org/CORBA/ORB/InconsistentTypeCode:1.0" );
    }

    public InconsistentTypeCode( String reason_str )
    { // full constructor
        super( "IDL:omg.org/CORBA/ORB/InconsistentTypeCode:1.0 " + reason_str );
    }
}
