package org.omg.CORBA;

/**
 * Holder class for deprecated WrongTransaction exception
 *
 * @deprecated Use the WRONG_TRANSACTION system exception
 */
final public class WrongTransactionHolder implements org.omg.CORBA.portable.Streamable
{
    /**
     * Internal holder variable for the WrongTransaction exception
     */
    public WrongTransaction value;

    /**
     * Default Constructor
     */
    public WrongTransactionHolder()
    {}

    /**
     * Constructor
     *
     * @param WrongTransaction exception for initializing this class
     */
    public WrongTransactionHolder( WrongTransaction initial )
    {
        value = initial;
    }

    /**
     * Read a WrongTransaction exception from an InputStream
     * 
     * @param InputStream to read the exception from.
     */
    public void _read( org.omg.CORBA.portable.InputStream in )
    {
        value = WrongTransactionHelper.read( in );
    }

    /**
     * Write a WrongTransaction exception into an OutputStream
     *
     * @param OutputStream to write the exception into
     */
    public void _write( org.omg.CORBA.portable.OutputStream out )
    {
        WrongTransactionHelper.write( out, value );
    }

    /**
     * Return the type code of the WrongTransaction exception
     */
    public TypeCode _type()
    {
        return WrongTransactionHelper.type();
    }

}
