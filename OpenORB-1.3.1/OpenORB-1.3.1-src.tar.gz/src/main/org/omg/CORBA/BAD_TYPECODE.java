package org.omg.CORBA;

/**
 * The ORB has encountered a malformed type code (for example, a
 * type code with an invalid <b>TCKind</b> value).
 */

public class BAD_TYPECODE extends org.omg.CORBA.SystemException
{
    //
    // Default constructor
    //
    public BAD_TYPECODE()
    {
        super( null, 0, CompletionStatus.COMPLETED_MAYBE );
    }

    //
    // Constructor with reason string
    //
    public BAD_TYPECODE( String orb_reason )
    {
        super( orb_reason, 0, CompletionStatus.COMPLETED_MAYBE );
    }

    //
    // Constructor with fields initialization
    // @param minor minor exception member
    // @param completed completed exception member
    //
    public BAD_TYPECODE( int minor, org.omg.CORBA.CompletionStatus completed )
    {
        super( null, minor, completed );
    }

    //
    // Full constructor with fields initialization
    // @param minor minor exception member
    // @param completed completed exception member
    //
    public BAD_TYPECODE( String orb_reason, int minor, org.omg.CORBA.CompletionStatus completed )
    {
        super( orb_reason, minor, completed );
    }
}
