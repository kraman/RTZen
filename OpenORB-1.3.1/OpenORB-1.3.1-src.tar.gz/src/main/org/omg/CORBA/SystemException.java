/***** Copyright (c) 1999 Object Management Group. Unlimited rights to
     duplicate and use this code are hereby granted provided that this 
     copyright notice is included.
*****/

package org.omg.CORBA;

import org.apache.avalon.framework.CascadingThrowable;
import org.openorb.util.JREVersion;

public abstract class SystemException extends RuntimeException implements CascadingThrowable
{
    private static final boolean JRE_1_4 = JREVersion.V1_4;
    
    public int minor;
    public CompletionStatus completed;

    private Throwable cause = this;

    protected SystemException( final String reason, final int minor,
            final CompletionStatus completed )
    {
        super( reason );
        this.minor = minor;
        this.completed = completed;
    }
    
    public Throwable initCause( final Throwable cause ) 
    {
        if ( JRE_1_4 ) 
        {
            return super.initCause( cause );
        }
        
        if ( this.cause != this )
        {
            throw new IllegalStateException( "Can't overwrite cause" );
        }
        if (cause == this)
        {
            throw new IllegalArgumentException( "Self-causation not permitted" );
        }
        
        this.cause = cause;

        return this;
    }

    public Throwable getCause() 
    {
        if ( JRE_1_4 ) 
        {
            return super.getCause();
        }
        return ( (cause == this) ? null : cause );
    }
    
}
