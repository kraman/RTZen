/***** Copyright (c) 1999 Object Management Group. Unlimited rights to
     duplicate and use this code are hereby granted provided that this 
     copyright notice is included.
*****/

package org.omg.CORBA;

/**
 * Helper class for deprecated Bounds exception.
 *
 * @deprecated Use org.omg.CORBA.TypeCodePackage.Bounds
 */

public final class BoundsHelper
{

    public static void insert( org.omg.CORBA.Any any, Bounds _value )
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static Bounds extract( org.omg.CORBA.Any any )
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static org.omg.CORBA.TypeCode type()
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static java.lang.String id()
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static Bounds read(
        org.omg.CORBA.portable.InputStream _input )
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static void write( org.omg.CORBA.portable.OutputStream _output,
                              Bounds _value )
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

}
