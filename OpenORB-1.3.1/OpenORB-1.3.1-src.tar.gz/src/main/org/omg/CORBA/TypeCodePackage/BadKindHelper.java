/***** Copyright (c) 1999 Object Management Group. Unlimited rights to
     duplicate and use this code are hereby granted provided that this 
     copyright notice is included.
*****/

package org.omg.CORBA.TypeCodePackage;

public final class BadKindHelper
{

    public static void insert( org.omg.CORBA.Any any,
                               org.omg.CORBA.TypeCodePackage.BadKind _value )
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static org.omg.CORBA.TypeCodePackage.BadKind extract(
        org.omg.CORBA.Any any )
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static org.omg.CORBA.TypeCode type()
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static java.lang.String id()
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static org.omg.CORBA.TypeCodePackage.BadKind read(
        org.omg.CORBA.portable.InputStream _input )
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static void write ( org.omg.CORBA.portable.OutputStream _output,
                               org.omg.CORBA.TypeCodePackage.BadKind _value )
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

}
