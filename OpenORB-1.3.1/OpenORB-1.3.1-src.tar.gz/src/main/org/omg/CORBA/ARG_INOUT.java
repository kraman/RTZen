package org.omg.CORBA ;

public interface ARG_INOUT
{
    public static final int value = 3 ;
}
