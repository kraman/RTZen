/***** Copyright (c) 1999 Object Management Group. Unlimited rights to
     duplicate and use this code are hereby granted provided that this 
     copyright notice is included.
*****/

package org.omg.CORBA;

/**
* @deprecated Principal
*/

public class Principal
{

    /**
    * @deprecated Deprecated by CORBA 2.2
    */
    public byte[] name()
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    /**
    * @deprecated Deprecated by CORBA 2.2
    */
    public void name( byte[] name )
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }
}
