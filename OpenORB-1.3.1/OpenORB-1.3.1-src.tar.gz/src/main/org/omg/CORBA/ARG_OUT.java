package org.omg.CORBA ;

public interface ARG_OUT
{
    public static final int value = 2 ;

}
