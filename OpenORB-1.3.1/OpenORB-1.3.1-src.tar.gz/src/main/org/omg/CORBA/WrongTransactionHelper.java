package org.omg.CORBA;

/**
 * Helper class for deprecated WrongTransaction exception
 *
 * @deprecated Use the WRONG_TRANSACTION system exception
 */
public final class WrongTransactionHelper
{

    public static void insert( org.omg.CORBA.Any any, WrongTransaction _value )
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static WrongTransaction extract( org.omg.CORBA.Any any )
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static org.omg.CORBA.TypeCode type()
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static java.lang.String id()
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static WrongTransaction read(
        org.omg.CORBA.portable.InputStream _input )
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

    public static void write( org.omg.CORBA.portable.OutputStream _output,
                              WrongTransaction _value )
    {
        throw new org.omg.CORBA.NO_IMPLEMENT();
    }

}
