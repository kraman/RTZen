package org.omg.CORBA;

/**
 * This exception indicates that an IDL identifier is syntactically
 * invalid. It may be raised if, for example, an identifier passed
 * to the interface repository does not conform to IDL identifier
 * syntax, or if an illegal operation name is used with the DII.
 */

public class INV_IDENT extends org.omg.CORBA.SystemException
{
    //
    // Default constructor
    //
    public INV_IDENT()
    {
        super( null, 0, CompletionStatus.COMPLETED_MAYBE );
    }

    //
    // Constructor with reason string
    //
    public INV_IDENT( String orb_reason )
    {
        super( orb_reason, 0, CompletionStatus.COMPLETED_MAYBE );
    }

    //
    // Constructor with fields initialization
    // @param minor minor exception member
    // @param completed completed exception member
    //
    public INV_IDENT( int minor, org.omg.CORBA.CompletionStatus completed )
    {
        super( null, minor, completed );
    }

    //
    // Full constructor with fields initialization
    // @param minor minor exception member
    // @param completed completed exception member
    //
    public INV_IDENT( String orb_reason, int minor, org.omg.CORBA.CompletionStatus completed )
    {
        super( orb_reason, minor, completed );
    }
}

