package org.omg.CORBA;

//
// Helper class for : AbstractBase
//
// @author OpenORB Compiler
//

public class AbstractBaseHelper
{
    //
    // Insert AbstractBase into an any
    // param a an any
    // param t AbstractBase value
    //
    public static void insert( org.omg.CORBA.Any a, java.lang.Object t )
    {
        a.type( type() );
        write( a.create_output_stream(), t );
    }

    //
    // Extract AbstractBase from an any
    // @param a an any
    // @return the extracted AbstractBase value
    //
    public static java.lang.Object extract( org.omg.CORBA.Any a )
    {
        if ( !a.type().equal( type() ) )
            throw new org.omg.CORBA.MARSHAL();

        return read( a.create_input_stream() );
    }

    //
    // Internal TypeCode value
    //
    private static org.omg.CORBA.TypeCode _tc = null;
    private static boolean _working = false;

    //
    // Return the AbstractBase TypeCode
    // @return a TypeCode
    //
    public static org.omg.CORBA.TypeCode type()
    {
        if ( _tc == null )
            _tc = org.omg.CORBA.ORB.init().create_abstract_interface_tc( id(), "AbstractBase" );

        return _tc;
    }

    //
    // Return the AbstractBase IDL ID
    // @return an ID
    //
    public static String id()
    {
        return _id;
    }

    private final static String _id = "IDL:omg.org/CORBA/AbstractBase:1.0";

    //
    // Read AbstractBase from a marshalled stream
    // @param istream the input stream
    // @return the readed AbstractBase value
    //
    public static java.lang.Object read( org.omg.CORBA.portable.InputStream istream )
    {
        return ( ( org.omg.CORBA_2_3.portable.InputStream ) istream ).read_abstract_interface();
    }

    //
    // Write AbstractBase into a marshalled stream
    // @param ostream the output stream
    // @param value AbstractBase value
    //
    public static void write( org.omg.CORBA.portable.OutputStream ostream, java.lang.Object value )
    {
        ( ( org.omg.CORBA_2_3.portable.OutputStream ) ostream ).write_abstract_interface( value );
    }

}
