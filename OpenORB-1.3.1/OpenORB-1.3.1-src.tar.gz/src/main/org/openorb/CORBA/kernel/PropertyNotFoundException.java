/*
* Copyright (C) The Community OpenORB Project. All rights reserved.
*
* This software is published under the terms of The OpenORB Community Software
* License version 1.0, a copy of which has been included with this distribution
* in the LICENSE.txt file.
*/
package org.openorb.CORBA.kernel;

/**
 * This exception could be raised by OpenORB when a required property is not found.
 *
 * @author Jerome Daniel
 * @version $Revision: 1.5 $ $Date: 2002/07/16 11:20:52 $ 
 */
public class PropertyNotFoundException
    extends Exception
{
    public PropertyNotFoundException()
    {
    }

    public PropertyNotFoundException( String reason )
    {
        super( reason );
    }
}
